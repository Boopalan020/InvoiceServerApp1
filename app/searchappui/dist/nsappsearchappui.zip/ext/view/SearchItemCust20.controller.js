sap.ui.define(["sap/fe/core/PageController"],function(e){"use strict";return e.extend("ns.app.searchappui.ext.view.SearchItemCust20",{})});
//# sourceMappingURL=SearchItemCust20.controller.js.map